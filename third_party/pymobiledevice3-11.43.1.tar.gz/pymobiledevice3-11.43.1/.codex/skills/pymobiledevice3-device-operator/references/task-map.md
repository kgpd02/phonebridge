# Task Map

## Use This File

Read this file when the user asks to do something on-device and you need to map intent to the correct `pymobiledevice3` command group or code entry point.

## Connectivity And Discovery

- `doctor`: check what this *host* can reach a device with — usbmux reachability and Wi-Fi discovery, whether mDNS can leave the machine, native/userspace/tunneld availability. Needs no device, so run it first when nothing is found at all.
- `usbmux`: list devices, forward ports, inspect basic connectivity.
- `bonjour`: discover RemoteXPC and related network-visible services.
- `lockdown`: inspect values, pair or unpair, start tunnels, toggle Wi-Fi connections, basic device settings.
- `remote`: remote pairing and tunnel helpers for CoreDevice flows.
- `companion`: reach services on a paired companion device (e.g. Apple Watch) through the phone.

Start here when the task is blocked on "find the device", "connect to the device", "`--rsd` details", or "start a tunnel". When *no* device shows up at all, run `pymobiledevice3 doctor` before guessing: it separates a host that cannot discover devices from a device that is not there.

Explicit tunnel setup is rarely needed: on iOS 17.4+, commands that require an RSD tunnel establish a no-root tunnel automatically — the native `remoted` tunnel on macOS, the in-process userspace tunnel elsewhere — so just run the command. Reach for `tunneld` or `start-tunnel` (see `references/transport-and-safety.md`) only for iOS 17.0-17.3 devices or when the no-root path is not viable.

## Files, Containers, And App Data

- `afc`: media-domain shell, pull, push, ls, rm.
- `apps`: list/query/install/uninstall apps and work with app AFC/container helpers.
- `crash`: browse, pull, clear, watch crash reports and sysdiagnose artifacts.
- Services to inspect when extending: `services/afc.py`, `services/house_arrest.py`, `services/installation_proxy.py`, `services/crash_reports.py`.

Use these for browsing files, copying artifacts, or handling app containers.

## Device State, Logs, And Diagnostics

- `syslog`: live logs and collection.
- `diagnostics`: restart, shutdown, info, battery-related flows under `pymobiledevice3/cli/diagnostics/`.
- `notification`: observe or post Darwin notifications; `get-state` / `set-state` read and hold a notification's 64-bit state (iOS 27.2+, RSD tunnel).
- `pcap`: capture network traffic.
- `btlogger`: capture Bluetooth HCI packet logs (pcap/pcapng).
- `power-assertion`: keep the device awake for a task.
- `processes`: process inspection helpers outside full DVT flows.

Use these for observability, troubleshooting, and health checks.

## Apps, Profiles, Provisioning, And Activation

- `apps`: install (`--streaming` extracts on the device while uploading), uninstall, query.
- `profile`: configuration profile management.
- `provision`: provisioning profile helpers.
- `activation`: activation-related actions.
- `amfi`: Developer Mode enablement.
- `idam`: account/device-association flows when relevant.

Treat most of these as state-changing. Do not run them unless the user clearly asked.

## Backup, Restore, Recovery

- `backup2`: backup, restore, list, encryption and password flows.
- `restore`: recovery, ramdisk, TSS, update, erase, reboot, shell.
- Supporting code: `pymobiledevice3/restore/` and `pymobiledevice3/cli/restore.py`.

These are the highest-risk areas. Ask before destructive actions and prefer inspection first.

## SpringBoard, UI, And Browser Automation

- `springboard`: icon state, orientation, wallpapers, shell.
- `webinspector`: opened tabs, JS shell, launch, automation shell, CDP server.
- `developer wda`: launch/tap/press/unlock/list-items/screenshot/type/swipe/window-size/status.
- Services to inspect: `services/webinspector.py`, `services/web_protocol/*`, `services/wda.py`, `services/springboard.py`.

Use WebInspector for Safari/WebView automation and WDA for device UI automation.

## Developer Services And Instrumentation

- `mounter`: mount developer images.
- `cryptex`: manage personalized cryptexes via cryptexd (iOS 17+, requires an RSD tunnel) —
  list, auto-install a DDI from unpacked Restore assets, personalization identifiers,
  nonce inspection/rolling, uninstall.
- `developer dvt`: screenshot, sysmon, process control, oslog, device info, netstat, HAR, energy, location simulation, xcuitest, profiling. For a development-signed app only: `vm-regions PID`, `dyld-metrics PID` (launch timing and image counts), `memgraph PID OUT` (leaks; launch with `--env MallocStackLogging=1` for allocation backtraces) and `allocations BUNDLE_ID` (heap summary, or `--events` for every event with backtraces; relaunches the app). `core-profile-session stackshot` prints the call stacks of all threads of all processes (`--process PID/NAME` for one, `--json` for the raw stackshot), symbolicated when `developer fetch-symbols download` was run for the device. Kernel frames need `--kernelcache` (of the firmware the device runs) plus `--kernel-signatures` (blacktop/symbolicator `kernel` directory), and `ipsw` installed. `core-profile-session parse-live` traces live, strace-like: narrow it with `--fs` (syscalls that take a path), `--net`, `--proc`, `--io`, `--mem`, `--signal`, `--cred`, `--sync`, `--mach`, `--dyld`, `--xpc`, `--dispatch`, `--runloop` (groups add up; `events` with the same options lists what is captured), `-s SYSCALL` or `-e TRACE_CODE_NAME` (`events TEXT` finds the name), and `--process NAME`; `--json` prints one JSON object per trace; unfiltered output falls behind the device on any tunnel.
- `developer core-device`: file/process/app/device-info operations through CoreDevice flows; `launch-application --console` prints the app's stdout/stderr; `write-file` / `stat` / `rename` / `remove-file` / `create-directory` / `create-symlink` edit a file-service domain and `watch` streams its file changes (iOS 27+).
- `developer debugserver`: debugserver launch and LLDB bridging.
- `developer fetch-symbols`: symbol acquisition; `download` keeps symbols it already downloaded unless given `--force`.
- `developer accessibility`: audits, settings, notifications, item listing.
- `developer simulate-location`: DVT-based location simulation.
- `developer arbitration`: device arbitration (check-in/check-out for exclusive use).
- `developer shell`: IPython shell connected to a named developer service (exploration/R&D).
- Supporting code: `pymobiledevice3/cli/developer/` and `pymobiledevice3/services/dvt/`.

The authoritative list of top-level groups is `CLI_GROUPS` in `pymobiledevice3/__main__.py`;
if a goal maps to nothing above, scan it and the matching module under `pymobiledevice3/cli/`.

Read `references/transport-and-safety.md` before using these on iOS 17+.

## When The CLI Is Close But Not Exact

If the user needs a variation that the CLI does not expose:

1. Search the matching service under `pymobiledevice3/services/`.
2. Keep transport logic in `ServiceProviderDep`.
3. Add a thin async CLI wrapper instead of embedding protocol logic in the command handler.
4. Reuse existing patterns from `docs/guides/writing-commands-with-service-provider.md`.
